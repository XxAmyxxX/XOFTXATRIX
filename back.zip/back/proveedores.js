const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')


const app = express()

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', '*');
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next()
})

app.use(bodyParser.json())

const PUERTO = 9300

const conexion = mysql.createConnection(
    {
        host:'localhost',
        port: 3306,
        database:'intradroxinet',
        user:'root',
        password:''
    }
)

app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto ${PUERTO}`);
})

conexion.connect(error => {
    if(error) throw error
    console.log('Conexión exitosa a la base de datos');
})

app.get('/', (req, res) => {
    res.send('API')
})

app.get('/proveedores', (req, res) => {
    const query = `SELECT proveedor.*, GROUP_CONCAT(producto.nombre_producto SEPARATOR ', ') AS producto, GROUP_CONCAT(producto.precio SEPARATOR ', ') AS precio
    FROM proveedor
    LEFT JOIN producto ON proveedor.id_proveedor = producto.id_proveedor
    GROUP BY proveedor.id_proveedor;`
    
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
        }
    })
})

app.get('/proveedor/:id', (req, res) => {
    const { id } = req.params

    const query = `SELECT proveedor.*, 
    GROUP_CONCAT(producto.nombre_producto SEPARATOR ', ') AS producto, 
    GROUP_CONCAT(producto.precio SEPARATOR ', ') AS precio
FROM proveedor
LEFT JOIN producto ON proveedor.id_proveedor = producto.id_proveedor
WHERE proveedor.id_proveedor = ${id}
GROUP BY proveedor.id_proveedor;`
    
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
        }
    })
})

app.get('/proveedores/:id', (req, res) => {
    const { id } = req.params

    const query = `SELECT * FROM proveedor WHERE id_proveedor=${id};`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
        }
    })
})


app.post('/proveedores/agregar', (req, res) => {
    const { proveedores, activo } = req.body;

    // Construye la consulta SQL
    const query = 'INSERT INTO proveedor (proveedores, activo) VALUES (?, ?)';
    const values = [proveedores, activo];

    // Ejecuta la consulta
    conexion.query(query, values, (error, result) => {
        if (error) {
            console.error('Error al insertar el proveedor: ', error);
            return res.status(500).json('Ocurrió un error al insertar el proveedor');
        }

        console.log('Se insertó correctamente el proveedor');
        res.json('Se insertó correctamente el proveedor');
    });
});



app.put('/proveedores/actualizar/:id_proveedor', (req, res) => {
    const id_proveedor = req.params.id_proveedor;
    const { proveedores, activo } = req.body;

    const query = 'UPDATE proveedor SET proveedores=?, activo=? WHERE id_proveedor=?';

    conexion.query(query, [proveedores, activo, id_proveedor], (error, results) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json('Ocurrió un error al actualizar el proveedor');
        }
        console.log(`Se actualizó correctamente el proveedor con ID ${id_proveedor}`);
        res.json('Se actualizó correctamente el proveedor');
    });
});


