const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', '*');
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json());

const PUERTO = 7300;

const connection = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    database: 'intradroxinet',
    user: 'root',
    password: ''
});

app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto ${PUERTO}`);
});

connection.connect((err) => {
    if (err) {
        console.error('Error al conectar a la base de datos: ', err);
        return;
    }
    console.log('Conexión establecida correctamente');
});

app.get('/', (req, res) => {
    res.send('API');
});

// Ruta para recibir datos del front-end y agregarlos a la tabla 'factura'
// Ruta para recibir datos del front-end y agregarlos a la tabla 'factura'
app.post('/crearfactura', (req, res) => {
  const { nombre_cliente, dni_cliente, dni_empleado, total, detalle } = req.body;

  // Iniciar transacción para asegurar consistencia
  connection.beginTransaction(err => {
      if (err) {
          console.error('Error al iniciar transacción: ', err);
          return res.status(500).send('Error interno del servidor al crear factura');
      }

      // Insertar datos en la tabla 'factura' incluyendo el total de la compra
      const facturaData = { nombre_cliente, dni_cliente, dni_empleado, total };
      connection.query('INSERT INTO factura SET ?', facturaData, (error, results, fields) => {
          if (error) {
              connection.rollback(() => {
                  console.error('Error al insertar en la tabla factura: ', error);
                  res.status(500).send('Error interno del servidor al crear factura');
              });
              return;
          }

          console.log('Datos insertados en la tabla factura correctamente');

          // Obtener el ID de la factura insertada
          const id_factura = results.insertId;

          // Actualizar la cantidad de productos vendidos en la tabla 'productos'
          detalle.forEach(item => {
              const { Nombre_producto, cantidad } = item;
              connection.query('UPDATE producto SET Cantidad_productos = Cantidad_productos - ? WHERE Nombre_producto = ?', [cantidad, Nombre_producto], (err, results) => {
                  if (err) {
                      connection.rollback(() => {
                          console.error(`Error al actualizar la cantidad de ${Nombre_producto}:`, err);
                          res.status(500).send('Error interno del servidor al crear factura');
                      });
                      return;
                  }
                  console.log(`Cantidad de ${Nombre_producto} actualizada correctamente`);
              });
          });

          // Insertar datos en la tabla 'detalle_factura'
          const detalleInsertions = detalle.map(item => {
              return new Promise((resolve, reject) => {
                  const detalleFacturaData = {
                      id_factura,
                      Nombre_producto: item.Nombre_producto,
                      cantidad: item.cantidad,
                      Valor_unitario: item.Valor_unitario
                  };

                  connection.query('INSERT INTO detalle_factura SET ?', detalleFacturaData, (err, results) => {
                      if (err) {
                          reject(err);
                      } else {
                          console.log('Datos insertados en la tabla detalle_factura correctamente');
                          resolve();
                      }
                  });
              });
          });

          // Ejecutar todas las inserciones de detalle en paralelo
          Promise.all(detalleInsertions)
              .then(() => {
                  // Commit la transacción si todo fue exitoso
                  connection.commit(err => {
                      if (err) {
                          connection.rollback(() => {
                              console.error('Error al hacer commit de la transacción: ', err);
                              res.status(500).send('Error interno del servidor al crear factura');
                          });
                      } else {
                          console.log('Transacción completada. Factura creada exitosamente');
                          res.status(200).send('Factura creada exitosamente');
                      }
                  });
              })
              .catch(error => {
                  connection.rollback(() => {
                      console.error('Error al insertar detalles de factura: ', error);
                      res.status(500).send('Error interno del servidor al crear factura');
                  });
              });
      });
  });
});

