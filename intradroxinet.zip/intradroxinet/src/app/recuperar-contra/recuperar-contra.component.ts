import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { RecuperarContraService } from './recuperar-contra.service';

@Component({
  selector: 'app-recuperar-contra',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './recuperar-contra.component.html',
  styleUrl: './recuperar-contra.component.css'
})
export class RecuperarContraComponent {
 
  email: string = '';
  message: string = '';

  constructor(private recuperarContraService: RecuperarContraService) { }

  requestPasswordReset() {
    console.log('Correo electrónico enviado:', this.email); // Imprime el correo electrónico enviado
    this.recuperarContraService.requestPasswordReset(this.email).subscribe(
      () => {
        this.message = 'Se ha enviado el correo electrónico para restablecer la contraseña.';
      },
      error => {
        if (error instanceof HttpErrorResponse) {
          // Manejar el caso en que la respuesta del servidor no sea JSON válido
          this.message = 'Error al enviar el correo electrónico para restablecer la contraseña. Respuesta no válida del servidor.';
        } else {
          // Manejar otros errores
          console.error('Error al enviar el correo electrónico para restablecer la contraseña', error);
          this.message = 'Error al enviar el correo electrónico para restablecer la contraseña. Por favor, inténtelo de nuevo.';
        }
      }
    );
    
  }

}