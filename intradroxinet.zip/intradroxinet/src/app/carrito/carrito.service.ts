import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarritoService {
  private cartItems: any[] = [];
  private carritoVaciadoSubject: Subject<void> = new Subject<void>();
  private productoAgregadoSubject: Subject<void> = new Subject<void>();

  constructor() { }

  getCartItems(): any[] {
    return this.cartItems;
  }

  agregarAlCarrito(producto: any): void {
    this.cartItems.push(producto);
    this.productoAgregadoSubject.next();
  }

  eliminarProducto(idProducto: number): void {
    this.cartItems = this.cartItems.filter((producto) => producto.id !== idProducto);
    this.carritoVaciadoSubject.next();
  }
  
  vaciarCarrito(): void {
    this.cartItems = [];
    this.carritoVaciadoSubject.next();
  }

  getCarritoVaciadoSubject(): Subject<void> {
    return this.carritoVaciadoSubject;
  }

  getProductoAgregadoSubject(): Subject<void> {
    return this.productoAgregadoSubject;
  }
}
