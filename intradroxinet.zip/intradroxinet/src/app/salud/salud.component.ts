import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ArticulosService } from './articulos.service';
import { NavComponent } from "../nav/nav.component";
import { NavAdminComponent } from "../nav-admin/nav-admin.component";

@Component({
    selector: 'app-salud',
    standalone: true,
    templateUrl: './salud.component.html',
    styleUrl: './salud.component.css',
    imports: [FormsModule, CommonModule, NavComponent, NavAdminComponent]
})

export class SaludComponent {
  articulos:any;
  categorias:any;


  art={
    id_producto:0,
    nombre_producto:"",
    precio:0,
    Cantidad_productos:0,
    categorias:0,
    proveedores:0,
    id_Categoria:0,
    id_proveedor:0
  }
  proveedores:any;
  pro={
    id_proveedor:0,
    proveedores:"",
    Activo:0
  }

  constructor(private articulosServicio: ArticulosService) {
    this.recuperarTodos();
    this.recuperarTodospro();
  }

  
  recuperarTodos() {
    this.articulosServicio.recuperarTodos().subscribe((result:any) => {
        console.log(result); // Agrega este console.log para ver el resultado
        this.articulos = result;
    });
}

recuperarTodospro(){
  this.articulosServicio.recuperarTodospro().subscribe((result: any) => {
    this.proveedores = result;
    console.log('Proveedores recuperados:', this.proveedores);
  });
}


  alta() {
    this.articulosServicio.alta(this.art).subscribe((datos:any) => {
        alert(datos);
        this.recuperarTodos();

    });
  }

  baja(id_producto:number) {
    this.articulosServicio.baja(id_producto).subscribe((datos:any) => {
      alert(datos);
      this.recuperarTodos();
    });
  }

  modificacion() {
    this.articulosServicio.modificacion(this.art).subscribe((datos: any) => {
      alert(datos);
      this.recuperarTodos();
    });
  }

  seleccionar(id_producto:number) {
    this.articulosServicio.seleccionar(id_producto).subscribe((result:any) => this.art = result[0]);
  }

  categoria() {
    this.articulosServicio.categoria().subscribe((result:any) => this.articulos = result);
    
  }
}
