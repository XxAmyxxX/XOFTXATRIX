import { Component, OnInit } from '@angular/core';
import { VentasService } from '../ventas.service';
import { CommonModule } from '@angular/common';
import { NavAdminComponent } from '../nav-admin/nav-admin.component';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable'; // Importar la extensión de tablas para jsPDF
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-reporte-ventas',
  standalone: true,
  imports: [CommonModule, NavAdminComponent],
  templateUrl: './reporte-ventas.component.html',
  styleUrls: ['./reporte-ventas.component.css']
})
export class ReporteVentasComponent implements OnInit {
  facturas: any[] = [];
  detallesFactura: any[] = [];
  productosUnicos: string[] = [];
  loading: boolean = true; // Variable para controlar la carga de datos

  constructor(private ventasService: VentasService) { }

  ngOnInit(): void {
    this.cargarDatos();
  }

  cargarDatos(): void {
    this.ventasService.getFacturas().subscribe(facturas => {
      this.facturas = facturas;
      let totalFacturas = this.facturas.length;
      let facturasCargadas = 0;

      this.facturas.forEach(factura => {
        this.ventasService.getDetallesFactura(factura.id_factura).subscribe(detalles => {
          this.detallesFactura.push(...detalles);
          facturasCargadas++;

          if (facturasCargadas === totalFacturas) {
            this.productosUnicos = this.obtenerProductosUnicos();
            this.loading = false; // Marcar como cargado cuando se obtengan todos los detalles
          }
        });
      });
    });
  }

  calcularTotalVentas(): number {
    return this.facturas.reduce((total, factura) => total + factura.total, 0);
  }

  obtenerProductosUnicos(): string[] {
    let productosUnicos: string[] = [];
    this.detallesFactura.forEach(detalle => {
      if (!productosUnicos.includes(detalle.Nombre_producto)) {
        productosUnicos.push(detalle.Nombre_producto);
      }
    });
    return productosUnicos;
  }

  calcularTotalCantidadVendida(producto: string): number {
    return this.detallesFactura
      .filter(detalle => detalle.Nombre_producto === producto)
      .reduce((total, detalle) => total + Number(detalle.cantidad), 0);
  }

  downloadPDF() {
    const doc = new jsPDF();
    doc.text('Reporte de Ventas - Totales Generales', 10, 10);
    doc.text(`Total de Ventas: ${this.calcularTotalVentas()}`, 10, 20);

    const tableData = this.productosUnicos.map(producto => [
      producto, 
      this.calcularTotalCantidadVendida(producto)
    ]);

    (doc as any).autoTable({
      head: [['Producto', 'Total Cantidad Vendida']],
      body: tableData,
      startY: 30
    });

    doc.save('reporte_ventas.pdf');
  }

  downloadExcel() {
    const data = this.productosUnicos.map(producto => ({
      Producto: producto,
      'Total Cantidad Vendida': this.calcularTotalCantidadVendida(producto)
    }));

    data.push({
      Producto: 'Total de Ventas',
      'Total Cantidad Vendida': this.calcularTotalVentas()
    });

    const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
    const wb: XLSX.WorkBook = { Sheets: { 'data': ws }, SheetNames: ['data'] };
    XLSX.writeFile(wb, 'reporte_ventas.xlsx');
  }
}
