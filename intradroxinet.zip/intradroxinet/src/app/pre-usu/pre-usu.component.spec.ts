import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreUsuComponent } from './pre-usu.component';

describe('PreUsuComponent', () => {
  let component: PreUsuComponent;
  let fixture: ComponentFixture<PreUsuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreUsuComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PreUsuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
