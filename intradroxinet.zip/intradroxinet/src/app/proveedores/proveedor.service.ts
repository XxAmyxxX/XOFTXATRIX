import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProveedorService {

  url='http://localhost:9300/'; 

  constructor(private http: HttpClient) { }

  recuperarTodos(): Observable<any>{
    return this.http.get<any>(`${this.url}proveedores`);
  } 

  obtenerDetalles(id_proveedor: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.url}proveedor/${id_proveedor}`);
  }

  alta(proveedores:any) {
    return this.http.post(`${this.url}proveedores/agregar`, proveedores);
  }

  seleccionar(id_proveedor:number) {
    return this.http.get(`${this.url}proveedores/${id_proveedor}`);
  }

  modificacion(proveedores: any) {
    return this.http.put(`${this.url}proveedores/actualizar/${proveedores.id_proveedor}`, proveedores);
  }
}