import { Component, OnInit } from '@angular/core';
import { ProveedorService } from './proveedor.service';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
 


@Component({
    selector: 'app-proveedores',
    standalone: true,
    templateUrl: './proveedores.component.html',
    styleUrl: './proveedores.component.css',
    imports: [NavAdminComponent,CommonModule,FormsModule]
})
export class ProveedoresComponent  implements OnInit {

  proveedores: any[] = [];
  detalles: any[] = [];

  pro = {
    id_proveedor: 0,
    proveedores: "",
    activo: true
  };
  
  
  mostrarDetalle: boolean = false;

  SeleccionadaId: number | null = null;

  editarProveedor: boolean = false;

  agregarProveedor: boolean = false;

  constructor(private poveedorService: ProveedorService) {}

  ngOnInit(): void {
    this.poveedorService.recuperarTodos().subscribe(
      (data) => {
        this.proveedores = data;
        console.log('Datos de proveedores:', this.proveedores); // Imprimir los datos en la consola
      },
      (error) => {
        console.error('Error al obtener proveedores:', error);
      }
    );
  }
  verDetalle(id_proveedor: number) {
    this.poveedorService.obtenerDetalles(id_proveedor).subscribe((data: any) => {
      // Procesar los detalles de proveedores para mostrar productos con precios y nombres de proveedores
      this.detalles = data.map((detalle: any) => {
        const productos = detalle.producto.split(', ');
        const precios = detalle.precio.split(', ').map(Number);
        return productos.map((producto: string, index: number) => {
          return { proveedor: detalle.proveedor, producto: producto, precio: precios[index] };
        });
      }).flat(); // Utiliza flat() para aplanar el arreglo de arreglos de productos y precios
      this.mostrarDetalle = true;
    });
  }
  
  volverAListar() {
    this.mostrarDetalle = false;
  }

  alta() {
    this.poveedorService.alta(this.pro).subscribe((datos: any) => {
      alert(datos);
      this.ngOnInit(); 
    });
  }
  
  AbrirAlta(): void {
    this.agregarProveedor = true; // Muestra el formulario de agregar
  }
  
  /*Para cerrar el formulario de agregar*/
  volverAgre() {
    this.agregarProveedor = false;
  }
  


  modificacion() {
    this.poveedorService.modificacion(this.pro).subscribe((datos:any) => {

        alert(datos);
        this.ngOnInit(); 
    });
  }

  seleccionar(id_proveedor: number): void {
    this.poveedorService.seleccionar(id_proveedor).subscribe(
      (result: any) => {
        this.pro = result[0]; // Asigna los detalles del proveedor seleccionado
        this.editarProveedor = true; // Muestra el formulario de edición
      },
      (error: any) => {
        console.error('Error al seleccionar el proveedor:', error);
      }
    );
  }
  /*Para cerrar el seleccionar*/
  volverSele() {
    this.editarProveedor = false;
  }
}