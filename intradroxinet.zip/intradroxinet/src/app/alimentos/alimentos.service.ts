import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlimentosService {

  url='http://localhost:4300/';
  

  constructor(private http: HttpClient) { }

  recuperarTodos() {
    return this.http.get(`${this.url}productos/alimentos`);
  }

  alta(articulo: any) {
    return this.http.post(`${this.url}productos/alimentos/agregar`, articulo);
  }
 
  baja(id_producto: number) {
    return this.http.delete(`${this.url}productos/borrar/${id_producto}`);
  }

  seleccionar(id_producto: number) {
    return this.http.get(`${this.url}productos/alimentos/${id_producto}`);
  }

  modificacion(articulo: any) {
    return this.http.put(`${this.url}productos/actualizar/${articulo.Id_producto}`, articulo);
  }

  recuperarTodospro(): Observable<any> {
    const request = this.http.get<any>(`${this.url}proveedores`);
    request.subscribe(data => console.log('Proveedores recuperados:', data));
    return request;
  } 
}