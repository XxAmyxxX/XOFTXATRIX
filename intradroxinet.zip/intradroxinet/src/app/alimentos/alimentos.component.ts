import { Component } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AlimentosService } from './alimentos.service';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";
import { Action } from 'rxjs/internal/scheduler/Action';

@Component({
    selector: 'app-alimentos',
    standalone: true,
    templateUrl: './alimentos.component.html',
    styleUrl: './alimentos.component.css',
    imports: [FormsModule, CommonModule, NavAdminComponent]
})
export class AlimentosComponent {
  articulos:any;

  art={
    id_producto:0,
    nombre_producto:"",
    precio:0,
    Cantidad_productos:0,
    categorias:0, 
    proveedores:0,
    id_Categoria:0,
    id_proveedor:0
  }
  proveedores:any;
  pro={
    id_proveedor:0,
    proveedores:"",
    Activo:0

  }
  constructor(private alimentoService: AlimentosService) {
    this.recuperarTodos();
    this.recuperarTodospro();
  }



  recuperarTodos() {
    this.alimentoService.recuperarTodos().subscribe((result: any) => {
      this.articulos = result;
    });
  }
  

  recuperarTodospro(){
    this.alimentoService.recuperarTodospro().subscribe((result: any) => {
      this.proveedores = result;
      console.log('Proveedores recuperados:', this.proveedores);
    });
  }

  alta() {
  
  
    this.alimentoService.alta(this.art).subscribe((datos: any) => {
      alert(datos);
      this.recuperarTodos();
    });
  }
  
  baja(id_producto:number) {
    this.alimentoService.baja(id_producto).subscribe((datos:any) => {
      alert(datos);
      this.recuperarTodos();
    });
  }

  modificacion() {
    this.alimentoService.modificacion(this.art).subscribe((datos:any) => {

        alert(datos);
        this.recuperarTodos();

    });
  }

  seleccionar(id_producto:number) {
    this.alimentoService.seleccionar(id_producto).subscribe((result:any) => this.art = result[0]);
  }

}
