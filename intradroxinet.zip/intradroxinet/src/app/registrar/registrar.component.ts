import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { LoginComponent } from '../login/login.component';

import { RegistrarService } from './registrar.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-registrar',
  standalone: true,
  imports: [RouterLink,LoginComponent,FormsModule],
  templateUrl: './registrar.component.html',
  styleUrl: './registrar.component.css'
})
export class RegistrarComponent {
  Nombres:string = "";
	Apellidos:string = "";
	Email:string = "";
	Num_celular:string = "";
	id_documento:string = "";
	Numero_documento:string = "";
  password: string = '';
  errorMessage: string = '';

  constructor(private router: Router,private registrarService: RegistrarService) { }

  submitForm() {
    console.log('Nombres:', this.Nombres);
    console.log('Apellidos:', this.Apellidos);
    console.log('Email:', this.Email);
    console.log('Número de celular:', this.Num_celular);
    console.log('ID de documento:', this.id_documento);
    console.log('Número de documento:', this.Numero_documento);
    console.log('Contraseña:', this.password);

    // Crear un objeto con los datos del formulario
    const data = {
      Nombres: this.Nombres,
      Apellidos: this.Apellidos,
      Email: this.Email,
      Num_celular: this.Num_celular,
      id_documento: this.getIdDocumentoValue(),
      Numero_documento: this.Numero_documento,
      contraseña: this.password
    };

    // Llamar al servicio para enviar los datos al backend
    this.registrarService.registrar(data).subscribe(
      (response) => {
        // Manejar la respuesta del backend
        console.log('Respuesta del backend:', response);
        if (response.success) {
          // Redirigir al usuario a otra página si la respuesta es exitosa
          this.router.navigateByUrl('/login');
        } else {
          // Mostrar mensaje de error si la respuesta es falsa
          this.errorMessage = 'Error en el registro: ' + response.message;
        }
      },
      (error) => {
        // Manejar errores
        console.error('Error al enviar los datos al backend:', error);
        // Mostrar mensaje de error genérico en caso de error de comunicación
        this.errorMessage = 'Error en la comunicación con el servidor';
      }
    );
  }
    // Función para obtener el valor del tipo de documento
    getIdDocumentoValue(): number {
      if (this.id_documento === 'cc') {
        return 1;
      } else if (this.id_documento === 'cx') {
        return 2;
      } else {
        return 0; 
      }
    }
  
}