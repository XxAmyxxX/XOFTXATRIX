import { Component } from '@angular/core';
import { GestionUsuService } from './gestion-usu.service';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RolComponent } from "../rol/rol.component";

@Component({
    selector: 'app-gestion-usu',
    standalone: true,
    templateUrl: './gestion-usu.component.html',
    styleUrl: './gestion-usu.component.css',
    imports: [NavAdminComponent, CommonModule, FormsModule, RolComponent]
})
export class GestionUsuComponent {

  usuarios:any;

  usu={
    Id_Usu:0,
    Nombres:"",
    Apellidos:"",
    Email:"",
    Num_celular:0, 
    Id_documento:0,
    Numero_documento:0
  }

  roles:any;

  rol={
    id_Usurol:0,
    Numero_documento:0,
    id_rol:0
  }
  editarRol: boolean = false;

  editarUsuario: boolean = false;
  
  constructor(private gestionUsuService: GestionUsuService) {
    this.recuperarTodos();
  
  }


  recuperarTodos() {
    this.gestionUsuService.recuperarTodos().subscribe((result:any) => {
      this.usuarios = result;
      //console.log('Usuarios:', this.usuarios); // Mostrar datos en la consola
    });
  }

  baja(id_usu:number) {
    this.gestionUsuService.baja(id_usu).subscribe((datos:any) => {
      alert(datos);
      this.recuperarTodos();
    });
  }
  confirmarBorrado(idUsuario: number) {
    if (confirm("¿Estás seguro de que deseas borrar este usuario?")) {
        // Si el usuario confirma que desea borrar, llamar a la función baja
        this.baja(idUsuario);
    }
  }




  modificacion() {
   
    this.gestionUsuService.modificacion(this.usu).subscribe((datos: any) => {
        alert(datos);
        this.recuperarTodos();
    });
}


  seleccionar(id_Usu: number): void {
    this.gestionUsuService.seleccionar(id_Usu).subscribe(
      (result: any) => {
        this.usu = result[0]; // Asigna los detalles del proveedor seleccionado
        this.editarUsuario = true; // Muestra el formulario de edición
      },
      (error: any) => {
        console.error('Error al seleccionar el proveedor:', error);
      }
    );
  }
  /*Para cerrar el seleccionar*/
  volverSele() {
    this.editarUsuario = false;
  }



}