import { Component } from '@angular/core';
import { RolService } from './rol.service';
import { FormsModule } from '@angular/forms';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";


@Component({
    selector: 'app-rol',
    standalone: true,
    templateUrl: './rol.component.html',
    styleUrl: './rol.component.css',
    imports: [FormsModule, NavAdminComponent, ]
})
export class RolComponent {
  roles:any;

  rol={
    id_Usurol:0,
    Numero_documento:"",
    id_rol:0
  }

  constructor(private rolService: RolService) {
    this.recuperarTodos();
  }


  recuperarTodos() {
    this.rolService.recuperarTodos().subscribe((result:any) => this.roles = result);
  }

  alta() {
    this.rolService.alta(this.rol).subscribe((datos:any) => {
      if (datos['resultado']=='OK') {
        alert(datos['mensaje']);
        this.recuperarTodos();
      }
    });
  }

  baja(codigo:number) {
    this.rolService.baja(codigo).subscribe((datos:any) => {
      if (datos['resultado']=='OK') {
        alert(datos['mensaje']);
        this.recuperarTodos();
      }
    });
  }

  modificacion() {
    this.rolService.modificacion(this.rol).subscribe((datos:any) => {
      if (datos['resultado']=='OK') {
        alert(datos['mensaje']);
        this.recuperarTodos();
      }
    });
  }

  seleccionar(codigo:number) {
    this.rolService.seleccionar(codigo).subscribe((result:any) => this.rol = result[0]);
  }



}