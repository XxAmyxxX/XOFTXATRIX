import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BellezaService {

  url='http://localhost:3300/';
  constructor(private http: HttpClient) { }
  recuperarTodos() {
    return this.http.get(`${this.url}productos/belleza`);
  }
  alta(articulo:any) {
    return this.http.post(`${this.url}productos/belleza/agregar`, articulo);
  }

  baja(id_producto:number) {
    return this.http.delete(`${this.url}producto/borrar/belleza/${id_producto}`);
  }

  seleccionar(id_producto:number) {
    return this.http.get(`${this.url}productos/belleza/${id_producto}`);
  }

  modificacion(articulo: any) {
    return this.http.put(`${this.url}productos/actualizar/${articulo.id_producto}`, articulo);
  }
  recuperarTodospro(): Observable<any> {
    const request = this.http.get<any>(`${this.url}proveedores`);
    request.subscribe(data => console.log('Proveedores recuperados:', data));
    return request;
  } 

}
