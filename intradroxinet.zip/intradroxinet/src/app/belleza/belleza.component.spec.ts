import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BellezaComponent } from './belleza.component';

describe('BellezaComponent', () => {
  let component: BellezaComponent;
  let fixture: ComponentFixture<BellezaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BellezaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BellezaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
