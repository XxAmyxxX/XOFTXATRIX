import { Component, OnInit  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FacturaService } from './factura.service';
import { FormsModule } from '@angular/forms';
import { CarritoService } from '../carrito/carrito.service';
import { NavCajeroComponent } from '../nav-cajero/nav-cajero.component';




@Component({
  selector: 'app-factura',
  standalone: true,
  imports: [CommonModule,FormsModule, NavCajeroComponent],
  templateUrl: './factura.component.html',
  styleUrl: './factura.component.css'
})
export class FacturaComponent implements OnInit {
  productosEnFactura: any[] = [];
  nombreCliente: string = '';
  dniCliente: string = '';
  dniempleado:string ='';
  compraRealizada: boolean = false;
  http: any;

  constructor(private facturaService: FacturaService, private carritoService: CarritoService ) { }

  ngOnInit(): void {
    // Obtener los datos del carrito desde el servicio de factura
    this.productosEnFactura = this.facturaService.getDatosCarrito();
  }
  calcularPrecioTotal(producto: any): void {
    producto.precioTotal = producto.cantidadSeleccionada * producto.precio;
  }

  calcularPrecioTotalProducto(producto: any): number {
    return producto.precioTotal || 0;
  }
  calcularTotal(): number {
    let total = 0;
    for (let producto of this.productosEnFactura) {
      total += this.calcularPrecioTotalProducto(producto);
    }
    return total;
  }

  calcularVuelto(): number {
    const total = this.calcularTotal();
    const cantidadPagada = Number((<HTMLInputElement>document.getElementById('pago')).value); // Obtener la cantidad pagada del input
    if (!isNaN(cantidadPagada)) {
      return cantidadPagada - total;
    } else {
      return 0;
    }
  }
  eliminar(idProducto: number): void {
    // Filtrar los productos y eliminar el producto con el ID especificado
    this.productosEnFactura = this.productosEnFactura.filter(pro => pro.id_producto !== idProducto);
  }
  comprar(): void {
    if (typeof this.dniCliente === 'string' && this.dniCliente.trim() === '') {
      alert('Por favor, complete todos los campos antes de realizar la compra.');
      return;
    }
    const total = this.calcularTotal();

    const datosFactura = {
      nombre_cliente: this.nombreCliente,
      dni_cliente: this.dniCliente,
      dni_empleado: this.dniempleado,
      total : total,
      detalle: this.productosEnFactura.map(producto => ({
        Nombre_producto: producto.nombre_producto,
        cantidad: producto.cantidadSeleccionada,
        Valor_unitario: producto.precio
      }))
    };

    // Llamar al servicio para enviar los datos al servidor
    this.facturaService.enviarFactura(datosFactura).subscribe(
      error => {
        alert('Error al enviar datos al servidor:');
      },
      response => {
        
        alert('Factura creada con exito')
        this.resetearDatos(); 
      }
    );
  }

  resetearDatos(): void {
    this.nombreCliente = '';
    this.dniCliente = '';
    this.dniempleado = '';
    this.productosEnFactura = [];
  }
}

