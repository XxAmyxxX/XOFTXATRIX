import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VentasService {
  private apiUrl = 'http://localhost:12300'; // URL base de tu backend

  constructor(private http: HttpClient) { }

  getFacturas(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/facturas`);
  }

  getDetallesFactura(idFactura: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/detalles-factura/${idFactura}`);
  }
}

