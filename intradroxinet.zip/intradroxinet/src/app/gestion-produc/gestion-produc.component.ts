import { Component } from '@angular/core';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";

@Component({
    selector: 'app-gestion-produc',
    standalone: true,
    templateUrl: './gestion-produc.component.html',
    styleUrl: './gestion-produc.component.css',
    imports: [NavAdminComponent]
})
export class GestionProducComponent {

}
