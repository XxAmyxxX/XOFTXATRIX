import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RestablecerContraService {
  private baseURL = 'http://localhost:11300';

  constructor(private http: HttpClient) { }

  resetPassword(token: string, newPassword: string) {
    return this.http.post(`${this.baseURL}/reset-password`, { token, newPassword });
  }
}
