import { Component, OnInit } from '@angular/core';
import { RestablecerContraService } from './restablecer-contra.service';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-restablecer-contra',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './restablecer-contra.component.html',
  styleUrl: './restablecer-contra.component.css'
})
export class RestablecerContraComponent implements OnInit {

 
  token: string= '';
  newPassword: string = '';
  message: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private restablecerContraService: RestablecerContraService
  ) { }

  ngOnInit(): void {
    // Obtener el token de la URL
    this.route.queryParams.subscribe(params => {
      this.token = params['token'];
    });
  }

  resetPassword() {
    this.restablecerContraService.resetPassword(this.token, this.newPassword).subscribe(
      () => {
        this.message = 'Se ha restablecido la contraseña correctamente.';
        // Redirigir al usuario al componente de inicio de sesión
        this.router.navigate(['/login']);
      },
      error => {
        if (error instanceof HttpErrorResponse) {
          // Manejar el caso en que la respuesta del servidor no sea JSON válido
          this.message = 'Error al restablecer la contraseña. Respuesta no válida del servidor.';
        } else {
          // Manejar otros errores
          console.error('Error al restablecer la contraseña', error);
          this.message = 'Error al restablecer la contraseña. Por favor, inténtelo de nuevo.';
        }
      }
    );
    
  }
}