import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegistrarComponent } from './registrar/registrar.component';
import { RolComponent } from './rol/rol.component';
import { PreAdminComponent } from './pre-admin/pre-admin.component';
import { PreCajeroComponent } from './pre-cajero/pre-cajero.component';
import { SaludComponent } from './salud/salud.component';
import { MomsComponent } from './moms/moms.component';
import { PersonalComponent } from './personal/personal.component';
import { BellezaComponent } from './belleza/belleza.component';
import { AlimentosComponent } from './alimentos/alimentos.component';
import { CategoriasComponent } from './categorias/categorias.component';
import { FacturaComponent } from './factura/factura.component';
import { ListarFacturaComponent } from './listar-factura/listar-factura.component';
import { ProveedoresComponent } from './proveedores/proveedores.component';
import { GestionUsuComponent } from './gestion-usu/gestion-usu.component';
import { RecuperarContraComponent } from './recuperar-contra/recuperar-contra.component';
import { RestablecerContraComponent } from './restablecer-contra/restablecer-contra.component';
import { ReporteVentasComponent } from './reporte-ventas/reporte-ventas.component';

export const routes: Routes = [
    {
        path:"home",
        component:HomeComponent
    },
    {
        path:"login",
        component:LoginComponent
    },
    {
        path:"registrar",
        component:RegistrarComponent
    },
    {
        path:"pres_admin",
        component:PreAdminComponent
      },
      {
        path:"pres_cajero",
        component:PreCajeroComponent
      },
      {
        path:"salud",
        component:SaludComponent
    },
    {
        path:"moms",
        component:MomsComponent
    },
    {
        path:"Personal",
        component:PersonalComponent
    },
    {
        path:"Belleza",
        component:BellezaComponent
    },
    {
        path:"Alimentos",
        component:AlimentosComponent
    },
    {
        path:"Categorias",
        component:CategoriasComponent
    },
    {
        path:"Factura",
        component:FacturaComponent
    },
    {
        path:"list_fact",
        component:ListarFacturaComponent
    },
    {
        path:"proveedores",
        component:ProveedoresComponent
    },
    {
        path:"gestion_usu",
        component:GestionUsuComponent
    },
    {
        path:"recuperar_contra",
        component:RecuperarContraComponent
    },
    {
        path:"restablecer_contra",
        component:RestablecerContraComponent
    },
    {
        path:"reporte_ventas",
        component:ReporteVentasComponent
    }
    
];
