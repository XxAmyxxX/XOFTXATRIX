import { Component, OnInit } from '@angular/core';
import { ListarFacturaService } from './listar-factura.service';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-listar-factura',
    standalone: true,
    templateUrl: './listar-factura.component.html',
    styleUrl: './listar-factura.component.css',
    imports: [NavAdminComponent, CommonModule]
})
export class ListarFacturaComponent  implements OnInit {
  facturas: any[] = [];
  detallesFactura: any[] = [];
  
  mostrarDetalle: boolean = false;
  facturaSeleccionadaId: number | null = null;

  constructor(private listarFacturaService: ListarFacturaService) {}

  ngOnInit() {
    this.listarFacturaService.obtenerFacturas().subscribe(
      (data: any[]) => {
       /* console.log('Datos de facturas recibidos:', data);*/
        this.facturas = data;
      },
      (error) => {
        console.error('Error al recuperar facturas:', error);
      }
    );
  }

  verDetalleFactura(idFactura: number,imprimir: boolean = false) {
    this.listarFacturaService.obtenerDetallesFactura(idFactura).subscribe(
      (detalle: any[]) => {
       /* console.log('Detalle de la factura:', detalle);*/
        this.detallesFactura = detalle;
        this.mostrarDetalle = true;
        this.facturaSeleccionadaId = idFactura;
        if (imprimir) {
          this.imprimirFactura();
        }
      },
      (error) => {
        console.error('Error al recuperar detalles de factura:', error);
      }
    );
  }

  imprimirFactura() {
    setTimeout(() => {
      const printContent = document.getElementById('detalle-factura');
      if (printContent) {
        const WindowPrt = window.open('', '', 'width=900,height=650');
        if (WindowPrt) {
          WindowPrt.document.write(printContent.innerHTML);
          WindowPrt.document.close();
          WindowPrt.focus();
          WindowPrt.print();
          WindowPrt.close();
        } else {
          console.error('Failed to open print window.');
        }
      } else {
        console.error('Print content not found.');
      }
    }, 0); // Ensure DOM is updated
  }
  
  volverAListarFacturas() {
    this.mostrarDetalle = false;
    this.facturaSeleccionadaId = null;
  }
}