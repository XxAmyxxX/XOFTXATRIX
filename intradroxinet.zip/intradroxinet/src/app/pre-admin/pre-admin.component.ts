import { Component } from '@angular/core';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";
import { ProductosService } from './productos.service';

import { CarritoService } from '../carrito/carrito.service';
import { FormsModule } from '@angular/forms';

@Component({
    selector: 'app-pre-admin',
    standalone: true,
    templateUrl: './pre-admin.component.html',
    styleUrl: './pre-admin.component.css',
    imports: [NavAdminComponent,FormsModule]
})
export class PreAdminComponent {
  productos: any[];

  constructor(private productosService: ProductosService, private carritoService: CarritoService) {
    this.productos = [];
    this.recuperarTodos();
  }

  agregarAlCarrito(producto: any): void {
    this.carritoService.agregarAlCarrito(producto);
  }

  trackById(index: number, item: any): number {
    return item.id_producto;
  }

  recuperarTodos() {
    this.productosService.recuperarTodos().subscribe((result: any) => this.productos = result);
  
  }
  
}