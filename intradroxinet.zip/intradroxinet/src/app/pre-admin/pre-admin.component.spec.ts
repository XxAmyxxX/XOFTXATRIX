import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreAdminComponent } from './pre-admin.component';

describe('PreAdminComponent', () => {
  let component: PreAdminComponent;
  let fixture: ComponentFixture<PreAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreAdminComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PreAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
