
<?php
$host = "localhost";
$usuario = "root";
$password = "";
$basededatos = "intradroxinet";

$conexion = new mysqli($host, $producto, $password, $basededatos);

if ($conexion->connect_error) {
    die("conexion establecida" . $conexion->connect_error);
}

header("Content-Type: application/json");
$metodo = $_SERVER['REQUEST_METHOD'];
$path = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '/';

$buscarId = explode('/', $path);
$Id_producto = ($path !== '/') ? end($buscarId) : null;

switch ($metodo) {
    // SELECT USUARIOS
    case 'GET':
        consulta($conexion, $Id_producto);
        break;

    // INSERT USUARIOS
    case 'POST':
        insertar($conexion);
        break;

    // UPDATE USUARIOS
    case 'PUT':
        actualizar($conexion, $Id_producto);
        break;

    // DELETE USUARIOS
    case 'DELETE':
        borrar($conexion, $Id_producto);
        break;

    default:
        echo "metodo no permitido";
        break;
}

function consulta($conexion, $Id_producto)
{
    $sql = ($Id_producto === null) ? "SELECT * FROM producto" : "SELECT * FROM producto WHERE Id_producto=$Id_producto";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        $datos = array();
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }

        echo json_encode($datos);
    }
}

function insertar($conexion)
{
    $dato = json_decode(file_get_contents('php://input'), true);
    $nombre = $dato['nombre_producto'];

    $sql = "INSERT INTO producto (nombre_producto) VALUES ('$nombre')";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        $datos['Id_producto'] = $conexion->insert_id;
        echo json_encode($datos);
    } else {
        echo json_encode(array('error' => 'Error al crear producto'));
    }
}

function borrar($conexion, $Id_producto)
{
    echo "el Id_Usu a borrar es: " . $Id_producto;

    $sql = "DELETE FROM producto WHERE Id_producto  = $Id_producto";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        echo json_encode(array('mensaje' => 'producto borrado'));
    } else {
        echo json_encode(array('error' => 'Error al borrar producto));
    }
}

function actualizar($conexion, $Id_producto)
{
    $dato = json_decode(file_get_contents('php://input'), true);
    $nombre = $dato['nombre_producto'];
    echo "el Id_Usu a editar es: " . $Id_producto . " con el dato " . $nombre;
    $sql = "UPDATE producto SET nombre_producto  =  '$nombre'  WHERE Id_producto = $Id_producto";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        echo json_encode(array('mensaje' => 'prodcuto actualizado'));
    } else {
        echo json_encode(array('error' => 'Error al actualizar prodcuto'));
    }
}
?>

