
<?php
$host = "localhost";
$usuario = "root";
$password = "";
$basededatos = "intradroxinet";

$conexion = new mysqli($host, $categorias, $password, $basededatos);

if ($conexion->connect_error) {
    die("conexion establecida" . $conexion->connect_error);
}

header("Content-Type: application/json");
$metodo = $_SERVER['REQUEST_METHOD'];
$path = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '/';

$buscarId = explode('/', $path);
$id_Categoria = ($path !== '/') ? end($buscarId) : null;

switch ($metodo) {
    // SELECT USUARIOS
    case 'GET':
        consulta($conexion, $id_Categoria);
        break;

    // INSERT USUARIOS
    case 'POST':
        insertar($conexion);
        break;

    // UPDATE USUARIOS
    case 'PUT':
        actualizar($conexion, $id_Categoria);
        break;

    // DELETE USUARIOS
    case 'DELETE':
        borrar($conexion, $id_Categoria);
        break;

    default:
        echo "metodo no permitido";
        break;
}

function consulta($conexion, $id_Categoria)
{
    $sql = ($id_Categoria === null) ? "SELECT * FROM categorias" : "SELECT * FROM categorias WHERE id_Categoria=$id_Categoria";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        $datos = array();
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }

        echo json_encode($datos);
    }
}

function insertar($conexion)
{
    $dato = json_decode(file_get_contents('php://input'), true);
    $nombre = $dato['Categorias'];

    $sql = "INSERT INTO categorias (Categorias) VALUES ('$nombre')";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        $datos['id_Categoria'] = $conexion->insert_id;
        echo json_encode($datos);
    } else {
        echo json_encode(array('error' => 'Error al crear categoria'));
    }
}

function borrar($conexion, $id_Categoria)
{
    echo "el Id_Usu a borrar es: " . $id_Categoria;

    $sql = "DELETE FROM categorias WHERE id_Categoria = $id_Categoria";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        echo json_encode(array('mensaje' => 'categoria borrada'));
    } else {
        echo json_encode(array('error' => 'Error al borrar categoria'));
    }
}

function actualizar($conexion, $id_Categoria)
{
    $dato = json_decode(file_get_contents('php://input'), true);
    $nombre = $dato['Categorias'];
    echo "el Id_Usu a editar es: " . $id_Categoria . " con el dato " . $nombre;
    $sql = "UPDATE categorias SET Categorias =  '$nombre'  WHERE id_Categoria = $id_Categoria";
    $resultado = $conexion->query($sql);

    if ($resultado) {
        echo json_encode(array('mensaje' => 'Categoria actualizada'));
    } else {
        echo json_encode(array('error' => 'Error al actualizar categoria'));
    }
}
?>

