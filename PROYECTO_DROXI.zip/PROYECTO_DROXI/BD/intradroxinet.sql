-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-05-2024 a las 03:32:16
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `intradroxinet`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_Categoria` int(20) NOT NULL,
  `Categorias` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_Categoria`, `Categorias`) VALUES
(1, 'Salud'),
(2, 'Belleza'),
(3, 'Cuidado personal'),
(4, 'Alimentos y bebidas '),
(5, 'Mamás y bebes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_factura`
--

CREATE TABLE `detalle_factura` (
  `id_detalle` int(11) NOT NULL,
  `id_factura` int(11) DEFAULT NULL,
  `Nombre_producto` varchar(255) DEFAULT NULL,
  `cantidad` varchar(20) DEFAULT NULL,
  `Valor_unitario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_factura`
--

INSERT INTO `detalle_factura` (`id_detalle`, `id_factura`, `Nombre_producto`, `cantidad`, `Valor_unitario`) VALUES
(4, 5, 'Paracetamol', '1', 5000),
(5, 5, 'Ibuprofeno', '1', 6000),
(6, 6, 'Paracetamol', '2', 5000),
(7, 7, 'Paracetamol', '1', 5000),
(8, 8, 'Pañales', '5', 8000),
(9, 8, 'Chocolisto', '2', 1800),
(10, 9, 'Paracetamol', '2', 5000),
(11, 9, 'Ibuprofeno', '1', 6000),
(12, 9, 'Aspirina', '2', 4000),
(13, 10, 'Paracetamol', '1', 5000),
(14, 10, 'Ibuprofeno', '1', 6000),
(15, 11, 'Paracetamol', '1', 5000),
(16, 12, 'Amoxicilina', '36', 6800),
(17, 12, 'Loratadina', '1', 5500),
(18, 12, 'Cetirizina', '1', 6500),
(19, 12, 'Dipirona', '1', 4500),
(20, 13, 'Amoxicilina', '10', 6800),
(21, 14, 'Amoxicilina', '12', 6800),
(22, 14, 'Loratadina', '1', 5500),
(23, 15, 'Amoxicilina', '1', 6800),
(24, 15, 'Loratadina', '1', 5500),
(25, 16, 'Amoxicilina', '1', 6800),
(26, 17, 'Amoxicilina', '100', 6800),
(27, 17, 'Cetirizina', '15', 6500),
(28, 18, 'Loratadina', '1', 5500),
(29, 19, 'Amoxicilina', '10', 6800);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

CREATE TABLE `documento` (
  `Id_documento` int(20) NOT NULL COMMENT 'el id del documento sera la llave primaria, la cual genera que le dato no se repita durante la ejecucion',
  `tipo_documento` varchar(20) DEFAULT NULL COMMENT 'Nos permitira saber que tipo de documento tiene el usuario ( Cedula de ciudadania, cedula extranjera, etc...) '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `documento`
--

INSERT INTO `documento` (`Id_documento`, `tipo_documento`) VALUES
(1, 'Cedula'),
(2, 'Cedula extrangera');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `Id_estado` int(20) NOT NULL COMMENT 'sera la llave primaria, la cual genera que le dato no se repita.',
  `estado` varchar(20) NOT NULL COMMENT 'Este campo nos hace saber que estado tiene el usuario( activo,inactivo, inactivo vacacional)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`Id_estado`, `estado`) VALUES
(1, 'Activo'),
(2, 'Inactivo ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evento`
--

CREATE TABLE `evento` (
  `id_evento` int(20) NOT NULL,
  `evento` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `evento`
--

INSERT INTO `evento` (`id_evento`, `evento`) VALUES
(1, 'Entrada_producto'),
(2, 'Salida_producto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL,
  `nombre_cliente` varchar(255) DEFAULT NULL,
  `dni_cliente` varchar(20) DEFAULT NULL,
  `dni_empleado` int(11) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`id_factura`, `nombre_cliente`, `dni_cliente`, `dni_empleado`, `fecha`) VALUES
(5, 'Amylee', '123', 1011084584, '2024-03-28 23:10:19'),
(6, 'juan', '321', 1011084584, '2024-03-28 23:18:45'),
(7, 'sofia', '567', 1011084584, '2024-03-28 23:22:38'),
(8, 'Miguel', '987', 1011084584, '2024-03-28 23:24:33'),
(9, 'ana', '589', 1010174546, '2024-03-29 00:36:29'),
(10, 'amama', '89898', 1011084584, '2024-03-29 01:12:48'),
(11, 'huhui', '5767', 1011084584, '2024-03-29 01:14:07'),
(12, 'hh', '1', 1, '2024-04-02 17:10:49'),
(13, 'alex', '1010', 1010174546, '2024-04-02 17:15:34'),
(14, 'gyon', '1010', 1010174546, '2024-04-03 22:31:17'),
(15, 'alex', '101010', 10101010, '2024-04-05 00:24:11'),
(16, 'a', '1', 1, '2024-04-05 00:24:54'),
(17, 'andres', '101010', 101010, '2024-04-24 23:05:46'),
(18, 'o', '7', 71, '2024-04-24 23:26:48'),
(19, 'Alejandroxd', '1010', 1010174546, '2024-05-06 00:50:58');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `Id_inventario` int(20) NOT NULL,
  `id_producto` int(20) NOT NULL,
  `id_evento` int(20) DEFAULT NULL,
  `Fecha_evento` date NOT NULL,
  `Can_productos` int(200) NOT NULL,
  `total` int(40) DEFAULT NULL,
  `id_Usurol` int(20) NOT NULL,
  `Id_categorias` int(11) NOT NULL,
  `Id_proveedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`Id_inventario`, `id_producto`, `id_evento`, `Fecha_evento`, `Can_productos`, `total`, `id_Usurol`, `Id_categorias`, `Id_proveedor`) VALUES
(1, 6, 2, '2023-06-17', 23, 127, 1, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `Id_producto` int(20) NOT NULL,
  `nombre_producto` varchar(20) DEFAULT NULL,
  `precio` int(20) DEFAULT NULL,
  `id_Categoria` int(20) NOT NULL,
  `id_proveedor` int(20) NOT NULL,
  `Cantidad_productos` int(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`Id_producto`, `nombre_producto`, `precio`, `id_Categoria`, `id_proveedor`, `Cantidad_productos`) VALUES
(4, 'Amoxicilina', 6800, 1, 1, 56),
(10, 'Loratadina', 5500, 1, 2, 250),
(11, 'Cetirizina', 6500, 1, 1, 220),
(12, 'Dipirona', 4500, 1, 2, 170),
(13, 'Dexametasona', 10000, 1, 1, 80),
(14, 'Clorfenamina', 5500, 1, 2, 200),
(15, 'Metronidazol', 9000, 1, 1, 150),
(16, 'Atorvastatina', 12000, 1, 2, 130),
(17, 'Chocolisto', 1800, 4, 4, 224),
(18, 'H Platillo Galleta', 2500, 4, 11, 111),
(24, 'Polvo compacto MAC', 30000, 2, 2, 80),
(25, 'Rubor NARS', 18000, 2, 3, 100),
(52, 'Pañales', 8000, 5, 1, 100),
(68, 'Cepillo dental Colga', 1500, 3, 11, 150),
(87, 'teteros', 43000, 5, 2, 2),
(93, 'Pañitos', 4300, 5, 2, 2),
(95, 'Crema nivea', 89000, 3, 7, 234),
(96, 'Pestallina', 16000, 2, 7, 10),
(97, 'Pollet', 5500, 4, 11, 11),
(98, 'Aloha', 2500, 4, 11, 1),
(101, 'Coca cola', 3800, 4, 4, 224),
(102, 'Gel', 45000, 3, 7, 11),
(108, 'Omeprazol123', 46000, 1, 2, 12),
(136, 'Agua', 1500, 4, 11, 12),
(142, 'Pañales etapa 3', 6800, 5, 3, 12),
(147, 'Papel higiénico ', 5500, 3, 2, 33),
(186, 'prueba', 1000, 2, 12, 100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id_proveedor` int(20) NOT NULL,
  `proveedores` varchar(50) NOT NULL,
  `activo` tinyint(1) DEFAULT 1 COMMENT '1 indica que el proveedor está activo y 0 indica que está desactivado. '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`id_proveedor`, `proveedores`, `activo`) VALUES
(1, 'Farmalisto', 1),
(2, 'mediservis', 1),
(3, 'clínex Familia', 1),
(4, 'Cocacola', 1),
(7, 'Maybelline', 1),
(8, 'Vogue', 1),
(9, 'Colgate', 1),
(10, 'Pañales pequeñin', 1),
(11, 'Cremelado', 1),
(12, 'a', 0),
(31, 'amy', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `Id_ROL` int(20) NOT NULL COMMENT 'La llave primaria que nos permite que el valor no se repita ',
  `Roles` varchar(20) NOT NULL COMMENT 'Este campo nos permite ver dentrol del programa que tipo de rol tiene el usuario registrado (Cajero, Administrador)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`Id_ROL`, `Roles`) VALUES
(1, 'Administrador '),
(2, 'Cajero'),
(3, 'usuario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `Id_Usu` int(20) NOT NULL,
  `Nombres` varchar(20) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Num_celular` varchar(20) NOT NULL,
  `Id_documento` varchar(20) NOT NULL,
  `Numero_documento` int(20) NOT NULL,
  `Contraseña` varchar(255) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `token_timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`Id_Usu`, `Nombres`, `Apellidos`, `Email`, `Num_celular`, `Id_documento`, `Numero_documento`, `Contraseña`, `token`, `token_timestamp`) VALUES
(1, 'YON', 'VILLA', 'villajhon54@gmail.com', '3227137135', '1', 1010174546, '$2y$10$3W4kW6zp0gRhfp/HpMKQg.HdJ8/OlmS2FcI..YlHn7k0euhaUrL4m', '', '2024-01-22 05:52:41'),
(10, 'Alex', 'Henao', 'Alex@Henao.com', '322 8718629', '', 102030, '$2y$10$23kGMy.3BqEoqWcth38dO.X0tTjzvMIfRqBj6dL/Um3/z82SZ82aK', '', '2024-05-14 21:10:27'),
(12, 'os', 'tia', 'os@tia', '123', '1', 5, '$2y$10$qnr9Irs7c5d3KqFBSpAaJuO.im9H5jS.RWYIVd/TMauFFpnRRXrpy', '', '2024-05-13 01:52:59'),
(13, 'Admin', 'Prueba', 'Admin@Prueba.com', '3201564897', '1', 1010, '$2y$10$bAYEzgX77pL2U61wpTgNZ.DnzosEy3tgVVoWNl2XcjbSW24zABBk2', '', '2024-05-14 19:24:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuariorol`
--

CREATE TABLE `usuariorol` (
  `id_Usurol` int(20) NOT NULL,
  `Numero_documento` varchar(50) DEFAULT NULL,
  `id_rol` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

--
-- Volcado de datos para la tabla `usuariorol`
--

INSERT INTO `usuariorol` (`id_Usurol`, `Numero_documento`, `id_rol`) VALUES
(1, '1010174546', 2),
(2, '1010', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_Categoria`);

--
-- Indices de la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_factura` (`id_factura`);

--
-- Indices de la tabla `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`Id_documento`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`Id_estado`);

--
-- Indices de la tabla `evento`
--
ALTER TABLE `evento`
  ADD PRIMARY KEY (`id_evento`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`id_factura`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`Id_inventario`),
  ADD KEY `fk_producto` (`id_producto`),
  ADD KEY `fk_evento` (`id_evento`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`Id_producto`),
  ADD KEY `fk_Categoria` (`id_Categoria`),
  ADD KEY `fk_proveedor` (`id_proveedor`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id_proveedor`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`Id_ROL`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`Id_Usu`),
  ADD KEY `ID_DOCUMENTO` (`Id_documento`);

--
-- Indices de la tabla `usuariorol`
--
ALTER TABLE `usuariorol`
  ADD PRIMARY KEY (`id_Usurol`),
  ADD KEY `fk_rol` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_Categoria` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `evento`
--
ALTER TABLE `evento`
  MODIFY `id_evento` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `Id_inventario` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `Id_producto` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `id_proveedor` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `Id_Usu` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `usuariorol`
--
ALTER TABLE `usuariorol`
  MODIFY `id_Usurol` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  ADD CONSTRAINT `detalle_factura_ibfk_1` FOREIGN KEY (`id_factura`) REFERENCES `factura` (`id_factura`);

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `fk_Categoria` FOREIGN KEY (`id_Categoria`) REFERENCES `categorias` (`id_Categoria`),
  ADD CONSTRAINT `fk_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`);

--
-- Filtros para la tabla `usuariorol`
--
ALTER TABLE `usuariorol`
  ADD CONSTRAINT `fk_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`Id_ROL`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
