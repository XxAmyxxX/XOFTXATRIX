import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ArticulosService {

  url='http://localhost:9300/'; // disponer url de su servidor que tiene las páginas PHP

  constructor(private http: HttpClient) { }

  recuperarTodos() {
    return this.http.get(`${this.url}articulos`);
  }

  alta(articulo:any) {
    return this.http.post(`${this.url}articulos/agregar`, articulo);
  }

  baja(codigo:number) {
    return this.http.delete(`${this.url}articulos/borrar/${codigo}`);
  }

  seleccionar(codigo:number) {
    return this.http.get(`${this.url}articulos/${codigo}`);
  }

  modificacion(articulo:any) {
    return this.http.put(`${this.url}articulos/actualizar`, articulo);
  }
}
