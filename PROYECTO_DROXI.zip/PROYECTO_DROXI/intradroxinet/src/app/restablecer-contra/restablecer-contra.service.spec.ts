import { TestBed } from '@angular/core/testing';

import { RestablecerContraService } from './restablecer-contra.service';

describe('RestablecerContraService', () => {
  let service: RestablecerContraService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RestablecerContraService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
