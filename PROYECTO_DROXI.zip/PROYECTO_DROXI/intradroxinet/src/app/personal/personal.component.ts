import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PersonalService } from './personal.service';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";

@Component({
    selector: 'app-personal',
    standalone: true,
    templateUrl: './personal.component.html',
    styleUrl: './personal.component.css',
    imports: [FormsModule, CommonModule, NavAdminComponent]
})
export class PersonalComponent {
  articulos:any;

  art={
    id_producto:0,
    nombre_producto:"",
    precio:0,
    Cantidad_productos:0,
    categorias:0,
    proveedores:0,
    id_Categoria:0,
    id_proveedor:0
  }
  proveedores:any;
  pro={
    id_proveedor:0,
    proveedores:"",
    Activo:0
  }
  constructor(private personalServicio: PersonalService) {
    this.recuperarTodos();
    this.recuperarTodospro();
  }


  recuperarTodos() {
    this.personalServicio.recuperarTodos().subscribe((result:any) => this.articulos = result);
  }

  recuperarTodospro(){
    this.personalServicio.recuperarTodospro().subscribe((result: any) => {
      this.proveedores = result;
      console.log('Proveedores recuperados:', this.proveedores);
    });
  }
  alta() {
    this.personalServicio.alta(this.art).subscribe((datos:any) => {

        alert(datos);
        this.recuperarTodos();

    });
  }

baja(id_producto: number) {
    this.personalServicio.baja(id_producto).subscribe((datos: any) => {
       alert(datos);
       this.recuperarTodos();
    });
}

  modificacion() {
    this.personalServicio.modificacion(this.art).subscribe((datos:any) => {
     
        alert(datos);
        this.recuperarTodos();
      
    });
  }

  seleccionar(id_producto:number) {
    this.personalServicio.seleccionar(id_producto).subscribe((result:any) => this.art = result[0]);
  }


}
