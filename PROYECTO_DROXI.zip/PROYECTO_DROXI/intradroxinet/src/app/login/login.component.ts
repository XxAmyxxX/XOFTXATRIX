import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { HttpClientModule } from '@angular/common/http';
import { LoginService } from './login.service';
import { Router, RouterLink } from '@angular/router';
import { HomeComponent } from '../home/home.component';




@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, HttpClientModule,RouterLink,HomeComponent],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  documento: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private router: Router,private loginService: LoginService) { }

  submitForm() {
    const data = {
      Numero_documento: this.documento,
      contraseña: this.password
    };

    this.loginService.login(data).subscribe(
      (response: any) => {
        if (response.success) {
          if (response.role === 'admin') {
            this.router.navigateByUrl('/pres_admin');
          } else if (response.role === 'cajero') {
            this.router.navigateByUrl('/pres_cajero');
          } else {
            alert('Este usuario no cuenta con roles asignados');
          }
        } else {
          this.errorMessage = 'Usuario o contraseña incorrectos';
          
        }
      },
      (error) => {
        console.error('Error al enviar los datos al backend:', error);
        this.errorMessage = 'Error en la comunicación con el servidor';
      }
    );
  }
}