import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreCajeroComponent } from './pre-cajero.component';

describe('PreCajeroComponent', () => {
  let component: PreCajeroComponent;
  let fixture: ComponentFixture<PreCajeroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreCajeroComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PreCajeroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
