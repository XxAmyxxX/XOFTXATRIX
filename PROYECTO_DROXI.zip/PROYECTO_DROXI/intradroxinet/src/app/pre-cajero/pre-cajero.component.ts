import { Component } from '@angular/core';
import { NavCajeroComponent } from "../nav-cajero/nav-cajero.component";
import { ProductosService } from '../pre-admin/productos.service';
import { CarritoService } from '../carrito/carrito.service';

@Component({
    selector: 'app-pre-cajero',
    standalone: true,
    templateUrl: './pre-cajero.component.html',
    styleUrl: './pre-cajero.component.css',
    imports: [NavCajeroComponent]
})
export class PreCajeroComponent {
    productos: any[];
    terminoBusqueda: string = '';
  
    constructor(private productosService: ProductosService, private carritoService: CarritoService) {
      this.productos = [];
      this.recuperarTodos();
    }
  
    agregarAlCarrito(producto: any): void {
      this.carritoService.agregarAlCarrito(producto);
    }
  
    trackById(index: number, item: any): number {
      return item.id_producto;
    }
  
    recuperarTodos() {
      this.productosService.recuperarTodos().subscribe((result: any) => this.productos = result);
    
    }
    
  }