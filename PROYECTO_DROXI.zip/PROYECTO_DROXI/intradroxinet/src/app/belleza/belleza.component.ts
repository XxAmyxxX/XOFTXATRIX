import { Component } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BellezaService } from './belleza.service';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";

@Component({
    selector: 'app-belleza',
    standalone: true,
    templateUrl: './belleza.component.html',
    styleUrl: './belleza.component.css',
    imports: [FormsModule, CommonModule, NavAdminComponent]
})
export class BellezaComponent {
  articulos:any;

  art={
    id_producto:0,
    nombre_producto:"",
    precio:0,
    Cantidad_productos:0,
    categorias:0,
    proveedores:0,
    id_Categoria:0,
    id_proveedor:0
  }
  proveedores:any;
  pro={
    id_proveedor:0,
    proveedores:"",
    Activo:0
  }
  constructor(private bellezaServicio: BellezaService) {
    this.recuperarTodos();
    this.recuperarTodospro();
  }


  recuperarTodos() {
    this.bellezaServicio.recuperarTodos().subscribe((result:any) => this.articulos = result);
  }
  
  recuperarTodospro(){
    this.bellezaServicio.recuperarTodospro().subscribe((result: any) => {
      this.proveedores = result;
      console.log('Proveedores recuperados:', this.proveedores);
    });
  }

  alta() {
    this.bellezaServicio.alta(this.art).subscribe((datos:any) => {
      
        alert(datos);
        this.recuperarTodos();
      
    });
  }

  baja(id_producto:number) {
    this.bellezaServicio.baja(id_producto).subscribe((datos:any) => {
      alert(datos);
      this.recuperarTodos();
    });
  }

  modificacion() {
    this.bellezaServicio.modificacion(this.art).subscribe((datos:any) => {

        alert(datos);
        this.recuperarTodos();

    });
  }

  seleccionar(id_producto:number) {
    this.bellezaServicio.seleccionar(id_producto).subscribe((result:any) => this.art = result[0]);
  }


}
