import { TestBed } from '@angular/core/testing';

import { BellezaService } from './belleza.service';

describe('BellezaService', () => {
  let service: BellezaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BellezaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
