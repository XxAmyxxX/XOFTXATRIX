import { TestBed } from '@angular/core/testing';

import { MamisService } from './mamis.service';

describe('MamisService', () => {
  let service: MamisService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MamisService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
