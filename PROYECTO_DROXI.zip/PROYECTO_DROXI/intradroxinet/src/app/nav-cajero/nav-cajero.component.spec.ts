import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NavCajeroComponent } from './nav-cajero.component';

describe('NavCajeroComponent', () => {
  let component: NavCajeroComponent;
  let fixture: ComponentFixture<NavCajeroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NavCajeroComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NavCajeroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
