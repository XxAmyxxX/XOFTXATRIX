import { Component } from '@angular/core';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";

@Component({
    selector: 'app-categorias',
    standalone: true,
    templateUrl: './categorias.component.html',
    styleUrl: './categorias.component.css',
    imports: [NavAdminComponent]
})
export class CategoriasComponent {

}
