import { Component, OnInit } from '@angular/core';
import { ListarFacturaService } from './listar-factura.service';
import { NavAdminComponent } from "../nav-admin/nav-admin.component";
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-listar-factura',
    standalone: true,
    templateUrl: './listar-factura.component.html',
    styleUrl: './listar-factura.component.css',
    imports: [NavAdminComponent, CommonModule]
})
export class ListarFacturaComponent  implements OnInit {
  facturas: any[] = [];
  detallesFactura: any[] = [];
  
  mostrarDetalle: boolean = false;
  facturaSeleccionadaId: number | null = null;

  constructor(private listarFacturaService: ListarFacturaService) {}

  ngOnInit() {
    this.listarFacturaService.obtenerFacturas().subscribe(
      (data: any[]) => {
       /* console.log('Datos de facturas recibidos:', data);*/
        this.facturas = data;
      },
      (error) => {
        /*console.error('Error al recuperar facturas:', error);*/
      }
    );
  }

  verDetalleFactura(idFactura: number) {
    this.listarFacturaService.obtenerDetallesFactura(idFactura).subscribe(
      (detalle: any[]) => {
       /* console.log('Detalle de la factura:', detalle);*/
        this.detallesFactura = detalle;
        this.mostrarDetalle = true;
        this.facturaSeleccionadaId = idFactura;
      },
      (error) => {
       /* console.error('Error al recuperar detalles de factura:', error);*/
      }
    );
  }


  
  volverAListarFacturas() {
    this.mostrarDetalle = false;
    this.facturaSeleccionadaId = null;
  }
}