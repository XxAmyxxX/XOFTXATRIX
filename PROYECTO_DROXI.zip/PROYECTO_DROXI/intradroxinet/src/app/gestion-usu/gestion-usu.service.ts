import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GestionUsuService {

  url='http://localhost:10300/'; 

  constructor(private http: HttpClient) { }

  recuperarTodos(): Observable<any>{
    return this.http.get<any>(`${this.url}usuarios`);
  } 

  baja(id_usu:number) {
    return this.http.delete(`${this.url}usuario/borrar/${id_usu}`);
  }

  seleccionar(id_Usu:number) {
    return this.http.get(`${this.url}usuario/${id_Usu}`);
  }
  

modificacion(usuario: any) {
  return this.http.put(`${this.url}usuario/actualizar/${usuario.Id_Usu}`, usuario);
}

}