import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionUsuComponent } from './gestion-usu.component';

describe('GestionUsuComponent', () => {
  let component: GestionUsuComponent;
  let fixture: ComponentFixture<GestionUsuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GestionUsuComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GestionUsuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
