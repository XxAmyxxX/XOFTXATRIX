import { TestBed } from '@angular/core/testing';

import { GestionUsuService } from './gestion-usu.service';

describe('GestionUsuService', () => {
  let service: GestionUsuService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GestionUsuService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
