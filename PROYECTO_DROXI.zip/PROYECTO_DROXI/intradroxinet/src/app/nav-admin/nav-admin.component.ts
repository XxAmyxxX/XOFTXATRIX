import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; 
import { CarritoService } from '../carrito/carrito.service';
import { FacturaService } from '../factura/factura.service';

@Component({
  selector: 'app-nav-admin',
  standalone: true,
  imports: [],
  templateUrl: './nav-admin.component.html',
  styleUrl: './nav-admin.component.css'
})
export class NavAdminComponent implements OnInit {
  cartItems: any[] = [];
  productos: any[] = [];
  contadorProductos: number = 0; //contador de productos

  constructor(
    private carritoService: CarritoService,
    private facturaService: FacturaService,
    private router: Router // Inyecta el Router
  ) {}

  ngOnInit(): void {
    this.cartItems = this.carritoService.getCartItems();
    this.obtenerProductos();

    // Suscribirse al evento de carrito vaciado
    this.carritoService.getCarritoVaciadoSubject().subscribe(() => {
      // Actualizar la lista de productos cuando se vacíe el carrito
      this.obtenerProductos();
    });

    // Suscribirse al evento de producto agregado al carrito
    this.carritoService.getProductoAgregadoSubject().subscribe(() => {
      // Incrementar el contador
      this.contadorProductos++;
    });
  }

  obtenerProductos(): void {
    this.productos = this.carritoService.getCartItems();
    this.contadorProductos = this.productos.length; // Actualizar el contador
  }

  toggleCart(): void {
    // lógica para mostrar u ocultar el carrito
  }

  eliminarProducto(event: Event, idProducto: number): void {
    event.stopPropagation(); // Evitar que el evento se propague
    const index = this.cartItems.findIndex(item => item.id_producto === idProducto);
    if (index !== -1) {
      this.cartItems.splice(index, 1);
    }
  }

  vaciarCarrito(): void {
    console.log("Vaciar carrito llamado");
    this.carritoService.vaciarCarrito();
    this.contadorProductos = 0; // Reiniciar el contador al vaciar el carrito
  }

  comprar(): void {
    const productosEnCarrito = this.carritoService.getCartItems();
    
    // Enviar los datos del carrito al servicio de factura
    this.facturaService.setDatosCarrito(productosEnCarrito);

    // Después de completar la compra, puedes vaciar el carrito
    this.carritoService.vaciarCarrito();

    // Navegar a la página de factura después de la compra
    this.router.navigate(['/Factura']);
  }
}
