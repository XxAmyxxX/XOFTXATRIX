import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class FacturaService {
  
  private datosCarrito: any[] = [];

  url='http://localhost:7300/crearfactura';
  constructor(private http: HttpClient) { }


  setDatosCarrito(datos: any[]): void {
    this.datosCarrito = datos;
  }

  getDatosCarrito(): any[] {
    return this.datosCarrito; 
  }

  enviarFactura(datos: any) {
    return this.http.post<any>(this.url, datos);
  }


}
