import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { PreAdminComponent } from '../pre-admin/pre-admin.component';
import { PreCajeroComponent } from '../pre-cajero/pre-cajero.component';

@Component({
  selector: 'app-pre-usu',
  standalone: true,
  imports: [RouterLink,PreAdminComponent,PreCajeroComponent],
  templateUrl: './pre-usu.component.html',
  styleUrl: './pre-usu.component.css'
})
export class PreUsuComponent {

}
