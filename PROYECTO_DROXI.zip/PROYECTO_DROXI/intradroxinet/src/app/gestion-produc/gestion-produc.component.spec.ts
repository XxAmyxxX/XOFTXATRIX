import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GestionProducComponent } from './gestion-produc.component';

describe('GestionProducComponent', () => {
  let component: GestionProducComponent;
  let fixture: ComponentFixture<GestionProducComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GestionProducComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(GestionProducComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
