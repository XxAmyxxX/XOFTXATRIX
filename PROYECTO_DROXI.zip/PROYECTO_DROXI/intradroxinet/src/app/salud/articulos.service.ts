import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ArticulosService {

  url='http://localhost:5300/'; // disponer url de su servidor que tiene las páginas PHP

  constructor(private http: HttpClient) { }

  recuperarTodos() {
    return this.http.get(`${this.url}productos/salud`);
  }

  alta(articulo:any) {
    return this.http.post(`${this.url}productos/salud/agregar`, articulo);
  }

  baja(id_producto:number) {
    return this.http.delete(`${this.url}productos/borrar/${id_producto}`);
  }

  seleccionar(id_producto:number) {
    return this.http.get(`${this.url}productos/mamas/${id_producto}`);
  }
  
  modificacion(articulo: any) {
    return this.http.put(`${this.url}productos/actualizar/${articulo.Id_producto}`, articulo);
  }
  categoria(){
    return this.http.get(`${this.url}categorias`);
    
  }
  recuperarTodospro(): Observable<any> {
    const request = this.http.get<any>(`${this.url}proveedores`);
    request.subscribe(data => console.log('Proveedores recuperados:', data));
    return request;
  } 

}
