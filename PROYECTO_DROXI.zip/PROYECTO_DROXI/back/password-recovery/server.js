const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const PORT = 11300;

app.use(bodyParser.json());
app.use(cors());

const db = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  database: 'intradroxinet',
  user: 'root',
  password: ''
});

db.connect(err => {
  if (err) {
    console.error('Error al conectar con la base de datos:', err);
    return;
  }
  console.log('Conectado a la base de datos MySQL');
});
// Endpoint para solicitar la recuperación de contraseña
app.post('/request-password-reset', (req, res) => {
  const { email } = req.body;

  const query = 'SELECT * FROM usuario WHERE Email = ?';
  db.query(query, [email], (err, results) => {
    if (err) {
      console.error('Error de base de datos:', err);
      return res.status(500).json({ error: 'Error de base de datos', message: err.toString() });
    }

    if (results.length === 0) {
      console.log('Usuario no encontrado con el correo electrónico:', email);
      return res.status(404).json({ error: 'Usuario no encontrado', message: 'Usuario no encontrado con el correo electrónico' });
    }

    const user = results[0];
    console.log('Usuario encontrado:', user);

    const token = jwt.sign({ email: user.Email }, 'secreto', { expiresIn: '1h' });
    const resetLink = `http://localhost:4200/restablecer_contra?token=${token}`;
    const tokenTimestamp = new Date();

    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: 'tardesbnas@gmail.com',
        pass: 'ulvz zled myor rjkz'
      }
    });

    const mailOptions = {
      from: 'tardesbnas@gmail.com',
      to: user.Email,
      subject: 'Restablecer Contraseña',
      text: `Haz clic en el enlace para restablecer tu contraseña: ${resetLink}`
    };

    console.log('Enviando correo electrónico a:', user.Email);

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error al enviar correo electrónico:', error);
        return res.status(500).json({ error: 'Error al enviar correo electrónico', message: error.toString() });
      }

      const updateQuery = 'UPDATE usuario SET token = ?, token_timestamp = ? WHERE Email = ?';
      db.query(updateQuery, [token, tokenTimestamp, email], (err, results) => {
        if (err) {
          console.error('Error de base de datos:', err);
          return res.status(500).json({ error: 'Error de base de datos', message: err.toString() });
        }

        res.status(200).json({ message: 'Correo electrónico para restablecer contraseña enviado y token almacenado' });
      });
    });
  });
});

// Endpoint para resetear la contraseña
app.post('/reset-password', (req, res) => {
  const { token, newPassword } = req.body;

  try {
    const decoded = jwt.verify(token, 'secreto');
    const query = 'SELECT * FROM usuario WHERE Email = ? AND token = ?';

    db.query(query, [decoded.email, token], (err, results) => {
      if (err) {
        console.error('Error de base de datos:', err);
        return res.status(500).json({ error: 'Error de base de datos', message: err.toString() });
      }

      if (results.length === 0) {
        console.log('Token inválido o expirado para el correo electrónico:', decoded.email);
        return res.status(404).json({ error: 'Token inválido o expirado', message: 'Token inválido o expirado para el correo electrónico' });
      }

      const user = results[0];
      const currentTime = new Date();
      const tokenTimestamp = new Date(user.token_timestamp);
      const tokenAge = (currentTime - tokenTimestamp) / (1000 * 60 * 60);

      if (tokenAge > 1) {
        return res.status(400).json({ error: 'El token ha expirado', message: 'El token ha expirado' });
      }

      const hashedPassword = bcrypt.hashSync(newPassword, 8);

      const updateQuery = 'UPDATE usuario SET Contraseña = ?, token = NULL, token_timestamp = NULL WHERE Email = ?';
      db.query(updateQuery, [hashedPassword, decoded.email], (err, results) => {
        if (err) {
          console.error('Error de base de datos:', err);
          return res.status(500).json({ error: 'Error de base de datos', message: err.toString() });
        }

        res.status(200).json({ message: 'La contraseña ha sido restablecida' });
      });
    });
  } catch (error) {
    console.error('Token inválido o expirado:', error);
    res.status(400).json({ error: 'Token inválido o expirado', message: error.toString() });
  }
});

app.listen(PORT, () => {
  console.log(`El servidor está funcionando en el puerto ${PORT}`);
});
