// inicio.js
console.log('Iniciando backend...');

// Requiere/importa los archivos necesarios
require('./alimentos');
require('./belleza');
require('./endpoint');
require('./mamis');
require('./personal');
require('./productos');
require('./compras');
require('./factura_lis');
require('./proveedores');
require('./Gestion_Usuarios');
require('./password-recovery/server');

console.log('Backend inicializado correctamente.');

