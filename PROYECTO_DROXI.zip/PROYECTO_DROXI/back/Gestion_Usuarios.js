const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')

const app = express()

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', '*');
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next()
})

app.use(bodyParser.json())
 
const PUERTO = 10300

const conexion = mysql.createConnection(
    {
        host:'localhost',
        port: 3306,
        database:'intradroxinet',
        user:'root',
        password:''
    }
)

app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto ${PUERTO}`);
})

conexion.connect(error => {
    if(error) throw error
    console.log('Conexión exitosa a la base de datos');
})

app.get('/', (req, res) => {
    res.send('API')
})

app.get('/usuarios', (req, res) => {
    const query = `SELECT * FROM usuario;`

    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
        }
    })
})


app.delete('/usuario/borrar/:id', (req, res) => {
    const { id } = req.params

    const query = `DELETE FROM usuario WHERE Id_Usu=${id};`
    conexion.query(query, (error) => {
        if(error) console.error(error.message)

        res.json(`Se eliminó correctamente el usuario`)
    })
})
app.get('/usuario/:id', (req, res) => {
    const { id } = req.params

    const query = `SELECT * FROM usuario WHERE id_Usu=${id};`
    conexion.query(query, (error, resultado) => {
        if(error) return console.error(error.message)

        if(resultado.length > 0) {
            res.json(resultado)
        } else {
            res.json(`No hay registros`)
        }
    })
})


app.put('/usuario/actualizar/:id_Usu', (req, res) => {
    const id_Usu = req.params.id_Usu;
    const { Nombres, Apellidos, Email, Num_celular, id_documento, Numero_documento } = req.body;

   
    const query = 'UPDATE usuario SET Nombres=?, Apellidos=?, Email=?, Num_celular=?, id_documento=?, Numero_documento=? WHERE id_Usu=?';

    conexion.query(query, [Nombres, Apellidos, Email, Num_celular, id_documento, Numero_documento, id_Usu], (error, results) => {
        if (error) {
            console.error(error.message);
            return res.status(500).json('Ocurrió un error al actualizar el usuario');
        }
        console.log(`Se actualizó correctamente el usuario con ID ${id_Usu}`);
        res.json('Se actualizó correctamente el usuario');
    });
});

